#include "var_lib.h"
#ifndef __IFMO_DISTRIBUTED_CLASS_CHILD__H
#define __IFMO_DISTRIBUTED_CLASS_CHILD__H



void CHILD_PROC_START(Proc *this, balance_t init_bal);

#endif
