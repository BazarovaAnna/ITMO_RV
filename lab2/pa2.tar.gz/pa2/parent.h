#include "var_lib.h"
#ifndef __IFMO_DISTRIBUTED_CLASS_PARENT__H
#define __IFMO_DISTRIBUTED_CLASS_PARENT__H

//void both_writer(const char *, ...);
//void both_writer_with_messages(Message *const message, const char *frmt, ...);
void PARENT_PROC_START(Proc *this);

#endif
